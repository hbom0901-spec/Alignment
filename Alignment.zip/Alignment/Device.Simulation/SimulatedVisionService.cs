﻿using System;
using System.Threading.Tasks;
using Core.Abstractions;

namespace Device.Simulation
{
    public class SimulatedVisionService : IVisionService
    {
        private bool _isConnected;

        public Task<bool> ConnectAsync()
        {
            _isConnected = true;
            Console.WriteLine("[SimVision] Camera Connected.");
            return Task.FromResult(true);
        }

        public async Task<VisionResult> SnapAndAnalysisAsync(string patternName, double exposureTime)
        {
            if (!_isConnected) throw new Exception("Camera not connected!");

            // 模擬拍照延遲 500ms
            await Task.Delay(500);

            Console.WriteLine($"[SimVision] Capturing pattern: {patternName} with Exp: {exposureTime}");

            // 這裡回傳一個假座標 (你可以隨便改，甚至寫個 Random)
            return new VisionResult
            {
                Success = true,
                X = 100.5, // 假裝看到特徵點在 (100.5, 200.3)
                Y = 200.3,
                Theta = 0.0,
                Score = 0.99,
                Message = "OK"
            };
        }

        public Task DisconnectAsync()
        {
            _isConnected = false;
            return Task.CompletedTask;
        }
    }
}