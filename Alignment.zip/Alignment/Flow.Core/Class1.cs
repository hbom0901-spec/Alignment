﻿using System;
using System.Threading.Tasks;
using Core.Abstractions;
// 假設你的 AlignmentCoordinator 在 Alignment.Coordinator.Core 命名空間
using Alignment.Coordinator.Core.Abstractions;
using IVisionService = Core.Abstractions.IVisionService;

namespace Flow.Core
{
    public class MainFlowController
    {
        private readonly IVisionService _vision;
        private readonly IMotionService _motion;
        // private readonly IAlignmentCoordinator _alignCoord; // 未來要接上你的 Coordinator

        // 透過建構子注入 (Dependency Injection)
        // 這就是「去耦合」的關鍵：Controller 不知道現在是用真的還是假的硬體
        public MainFlowController(IVisionService vision, IMotionService motion)
        {
            _vision = vision;
            _motion = motion;
        }

        public async Task InitializeSystemAsync()
        {
            Console.WriteLine("=== System Initializing ===");
            await _motion.ConnectAsync();
            await _motion.HomeAsync();
            await _vision.ConnectAsync();
            Console.WriteLine("=== System Ready ===");
        }

        // 這是對位的主流程 (仿照 LabVIEW State Machine)
        public async Task RunAlignmentSequenceAsync(string recipeName)
        {
            try
            {
                Console.WriteLine($"--- Start Alignment Flow (Recipe: {recipeName}) ---");

                // Step 1: 手臂移動到拍照位置
                await _motion.MoveAbsoluteAsync(500, 500, 0);

                // Step 2: 拍照
                var visionResult = await _vision.SnapAndAnalysisAsync("Mark_A", 5000);

                if (!visionResult.Success)
                {
                    Console.WriteLine("Vision Failed!");
                    return;
                }

                // Step 3: (這裡未來要呼叫 Alignment.Core 計算補正量)
                // 目前先模擬計算
                double offsetX = 100 - visionResult.X; // 假設目標是 100
                double offsetY = 200 - visionResult.Y; // 假設目標是 200

                Console.WriteLine($"Calculated Offset: dX={offsetX}, dY={offsetY}");

                // Step 4: 補正移動
                if (Math.Abs(offsetX) > 0.01 || Math.Abs(offsetY) > 0.01)
                {
                    // 取得現在位置 + 補正量
                    var current = await _motion.GetPositionAsync();
                    await _motion.MoveAbsoluteAsync(current.x + offsetX, current.y + offsetY, current.u);
                    Console.WriteLine("Alignment Correction Done.");
                }
                else
                {
                    Console.WriteLine("No Correction Needed.");
                }

                Console.WriteLine("--- Flow Finished ---");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[Error] Flow Crashed: {ex.Message}");
            }
        }
    }
}